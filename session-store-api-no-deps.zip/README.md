# Spark Session Store API

A standalone Express service that stores session JSON objects in SparkDB Files API.

Each session is stored as a JSON file named:

- `session-<id>.json`

## What this project provides

- `POST /buckets/init` → create a Spark bucket (optional helper)
- `GET /buckets/:bucketId/objects` → inspect bucket objects
- `POST /sessions/:id` → create/save session JSON
- `PUT /sessions/:id` → update session JSON
- `GET /sessions/:id` → fetch session JSON
- `GET /sessions` → list session-like objects in bucket
- `DELETE /sessions/:id` → delete session by id

## Setup

1. Install dependencies:

```bash
npm install
```

2. Create `.env` from example:

```bash
cp .env.example .env
```

3. Set at least:

- `SPARK_API_KEY` (required)
- `SPARK_BUCKET_ID` (optional if you will call `POST /buckets/init` first)

4. Run service:

```bash
npm run dev
# or
npm start
```

## API usage examples

### 1) Create a bucket (if needed)

```bash
curl -X POST http://localhost:3000/buckets/init \
  -H "Content-Type: application/json" \
  -d '{"name":"sessions","public":false}'
```

### 2) Save a session

```bash
curl -X POST http://localhost:3000/sessions/user-123 \
  -H "Content-Type: application/json" \
  -d '{"user":"kenny","state":{"step":"otp"}}'
```

### 3) Fetch a session

```bash
curl http://localhost:3000/sessions/user-123
```

### 4) List sessions

```bash
curl http://localhost:3000/sessions
```

### 5) Delete session

```bash
curl -X DELETE http://localhost:3000/sessions/user-123
```

## Notes

- Session metadata cache is stored locally in `data/session-index.json`.
- The source of truth remains Spark storage objects.
- This project assumes Spark object list/upload responses include object identifiers and/or URLs (it handles common field name variants).
