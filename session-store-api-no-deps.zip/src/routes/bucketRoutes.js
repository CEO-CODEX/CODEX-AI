const express = require('express');

function createBucketRoutes({ sparkClient, sessionStore, config }) {
  const router = express.Router();

  router.post('/init', async (req, res, next) => {
    try {
      const name = req.body?.name || config.defaultBucketName;
      const isPublic = req.body?.public ?? config.defaultBucketPublic;

      const created = await sparkClient.createBucket({ name, isPublic });
      const bucketId = created?.id ?? created?.bucketId ?? created?.bucket_id;

      if (!bucketId) {
        return res.status(502).json({
          error: 'Bucket created but no bucket id was returned by Spark API',
          response: created
        });
      }

      sessionStore.setBucketId(String(bucketId));

      res.status(201).json({
        message: 'Bucket created and bound for this runtime',
        bucketId: String(bucketId),
        bucket: created
      });
    } catch (error) {
      next(error);
    }
  });

  router.get('/:bucketId/objects', async (req, res, next) => {
    try {
      const { bucketId } = req.params;
      const objects = await sparkClient.listObjects(bucketId);
      res.json({ bucketId, count: objects.length, objects });
    } catch (error) {
      next(error);
    }
  });

  return router;
}

module.exports = createBucketRoutes;
