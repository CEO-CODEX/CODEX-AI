const createApp = require('./app');
const config = require('./config');

const app = createApp();

app.listen(config.port, () => {
  console.log(`Session Store API running on http://localhost:${config.port}`);
});
