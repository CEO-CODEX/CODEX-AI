require("dotenv").config();
const path = require("path");

function parseBool(value, fallback = false) {
  if (value === undefined || value === null || value === "") return fallback;
  const normalized = String(value).trim().toLowerCase();
  return ["1", "true", "yes", "on"].includes(normalized);
}

const config = {
  port: Number(process.env.PORT || 3000),
  sparkApiBaseUrl: "https://api.sparkdb.pro/api/sdk",
  sparkApiKey: process.env.SPARK_API_KEY || "",
  sparkBucketId: process.env.SPARK_BUCKET_ID || "",
  defaultBucketName: process.env.DEFAULT_BUCKET_NAME || "sessions",
  defaultBucketPublic: parseBool(process.env.DEFAULT_BUCKET_PUBLIC, false),
  indexFilePath: path.join(__dirname, "..", "data", "session-index.json"),
};

module.exports = config;
