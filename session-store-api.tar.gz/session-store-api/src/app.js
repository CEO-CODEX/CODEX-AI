const express = require("express");
const config = require("./config");
const SparkFilesClient = require("./lib/sparkFilesClient");
const SessionStore = require("./lib/sessionStore");
const createSessionRoutes = require("./routes/sessionRoutes");
const createBucketRoutes = require("./routes/bucketRoutes");
const whatsappRoutes = require("../pairr/whatsapp");

function createApp() {
  const app = express();

  app.use(express.json({ limit: "2mb" }));

  const sparkClient = new SparkFilesClient({
    apiKey: config.sparkApiKey,
    baseUrl: config.sparkApiBaseUrl,
  });

  const sessionStore = new SessionStore({
    sparkClient,
    indexFilePath: config.indexFilePath,
    bucketId: config.sparkBucketId,
  });

  app.get("/health", (_req, res) => {
    res.json({
      ok: true,
      service: "spark-session-store-api",
      bucketConfigured: Boolean(sessionStore.bucketId),
    });
  });

  app.use(
    "/buckets",
    createBucketRoutes({ sparkClient, sessionStore, config }),
  );
  app.use("/sessions", createSessionRoutes({ sessionStore }));
  app.use("/whatsapp", whatsappRoutes);

  app.use((err, _req, res, _next) => {
    const statusCode = err?.response?.status || 400;
    const message =
      err?.response?.data?.message || err.message || "Unknown error";

    res.status(statusCode).json({
      error: message,
      details: err?.response?.data || null,
    });
  });

  return app;
}

module.exports = createApp;
